import React,{useState} from 'react';
import './Menu.css';
const ComponentCatalog = ({ onComponentSelect,itemsselected,handleSubmitPc}) => {
  const cpus = [
    {name : 'Intel Core i5 13600K', image:'13600K', price:450,category:'cpu', cores:14,friquency:"2.6GHz",socket:"LGA1700"},
    {name : 'AMD Ryzen 7 7700X', image:'7700X',price:350,category:'cpu', cores:8,friquency:"4.5GHz",socket:"AM5"}
  ];
  const gpus = [
    {name : 'Palit RTX 4080',image:'RTX4080PALIT', price:1400,category:'gpu', VRAM:"16gb",friquency:"2.2GHz",bit:"256"},
    {name : 'ASRock RX7900XT', image:'ASROCK7900XT',price:1200,category:'gpu', VRAM:"20gb",friquency:"1.5GHz",bit:"320"},
    {name : 'Встроенная графика', image:'nothing',price:0,category:'gpu', VRAM:"",friquency:"",bit:""},
  ];
  const motherboards = [
    {name : 'Gigabyte B650 AORUS ELITE AX', image:'AORUSB650',price:220, category:'motherboard', chipset:"B650",formfactor:"ATX",socket:"AM5",ramslots:4},
    {name : 'Gigabyte Z790 AORUS ELITE AX',image:'AORUSZ790', price:250, category:'motherboard', chipset:"Z790",formfactor:"ATX",socket:"LGA1700",ramslots:4},
  ];
  const rams = [
    {name : 'AXCorsair Vengeance LPX',image:'CORSAIRVENGEANCELPX', price:50, category:'ram', friquency:"3200Mhz",generation:"DDR4",capacity:"8GB x 2"},
    {name : 'G.Skill Trident Z5 RGB', image:'GSKILLTRIDENTZ5RGB',price:110, category:'ram', friquency:"6000Mhz",generation:"DDR5",capacity:"16GB x 2"},
  ];
  const storage_ssd = [
    {name:'Samsung 990 Pro',price:150,image:'SAMSUNG990PRO',category:'ssd',readspead:'7450Mb/s',writespead:'6900Mb/s',capacity:'1TB'},
    {name:'Samsung 990 Pro',price:220,image:'SAMSUNG990PRO',category:'ssd',readspead:'7450Mb/s',writespead:'6900Mb/s',capacity:'2TB'},
    {name:'Не хочу брать SSD',price:0,image:'nothing',category:'ssd',readspead:'',writespead:'',capacity:''},
  ];
  const storage_hdd = [
    {name:'Seagate Barracuda',price:60,image:'SEAGATEBARRACUDA',category:'hdd',spins:'7200p/Min',capacity:'2TB'},
    {name:'WD Caviar Blue',price:60,image:'WDCAVIARBLUE',category:'hdd',spins:'7200p/Min',capacity:'1TB'},
    {name:'Не хочу брать HDD',price:0,image:'nothing',category:'hdd',spins:'',capacity:''},
  ];
  const coolersystems = [
    {name:'Sapphire Nitro+ S240',price:190,image:'SAPPHIRENITROS240',category:'cooler',type:'Водное',noize:'36.2Db',sockets:'LGA1700,AM4,LGA1200,LGA1151,LGA1151v2,LGA1151',TDP:340},
    {name:'DeepCool Ak400',price:45,image:'DEEPCOOLAK400',category:'cooler',type:'Воздушное',noize:'28Db',sockets:'LGA1700,AM5,AM4,LGA1200,LGA1151,LGA1151v2,LGA1151',TDP:220},
  ];
  const psus = [
    {name:'DeepCool PK700D', price:70,image:'DEEPCOOLPK700D',category:'PSU',sertification:'Бронзовый(КПД 80%+)',formfactor:'ATX', power:'700w'},
  ];
  const cases = [
    {name:'Montech AIR 1000',price:75,image:'MONTECHAIR100',category:'case',type:'Mid tower',formfactors:'ATX,Micro ATX,MiniATX'}
  ]

  return (
    <div>
      {itemsselected === 0 ?(
      <div>
        <h3>Каталог процессоров</h3>
      <ul>
        {cpus.map((component) => (
          <div className='item-catalog'>
          <li key={component.name}>
            <img className='imglist' src={require(`./media/${component.image}.png`)} alt={component.name} />
            <h4 className='component-name'>{component.name}</h4>
            <p>Цена: ${component.price}</p>
            <p>Ядра: {component.cores}</p>
            <p>Тактовая частота: {component.friquency}</p>
            <p>Сокет: {component.socket}</p>
            <button className='button-5' onClick={() => onComponentSelect(component)}>Выбрать</button>
          </li></div>
        ))}
      </ul>
      </div>
      ) : itemsselected === 1 ?(
        <div>
      <h3>Каталог видеокарт</h3>
      <ul>
        {gpus.map((component) => (
          <div className='item-catalog'>
          <li key={component.name}>
            <img className='imglist' src={require(`./media/${component.image}.png`)} alt={component.name} />
            <h4 className='component-name'>{component.name}</h4>
            <p>Цена: ${component.price}</p>
            <p>Объём видеопамяти: {component.VRAM}</p>
            <p>Бит шина: {component.bit}</p>
            <p>Начальная частота: {component.friquency}</p>
            <button className='button-5' onClick={() => onComponentSelect(component)}>Выбрать</button>
          </li></div>
        ))}
      </ul>
      </div>
      ): itemsselected === 2 ?(
        <div>
      <h3>Каталог материнских плат</h3>
      <ul>
        {motherboards.map((component) => (
          <div className='item-catalog'>
          <li key={component.name}>
            <img className='imglist' src={require(`./media/${component.image}.png`)} alt={component.name} />
            <h4 className='component-name'>{component.name}</h4>
            <p>Цена: ${component.price}</p>
            <p>Чипсет: {component.chipset}</p>
            <p>Сокет: {component.socket}</p>
            <p>Разъемы для ОП: {component.ramslots}</p>
            <button className='button-5' onClick={() => onComponentSelect(component)}>Выбрать</button>
          </li></div>
        ))}
      </ul>
      </div>
      ): itemsselected === 3 ?(
        <div>
      <h3>Каталог оперативной памяти</h3>
      <ul>
        {rams.map((component) => (
          <div className='item-catalog'>
          <li key={component.name}>
            <img className='imglist' src={require(`./media/${component.image}.png`)} alt={component.name} />
            <h4 className='component-name'>{component.name}</h4>
            <p>Цена: ${component.price}</p>
            <p>Частота: {component.friquency}</p>
            <p>Поколение: {component.generation}</p>
            <p>Объем: {component.capacity}</p>
            <button className='button-5' onClick={() => onComponentSelect(component)}>Выбрать</button>
          </li>
          </div>
        ))}
      </ul>
      </div>
      ): itemsselected === 4 ?(
      <div>
      <h3>Каталог ССД</h3>
      <ul>
        {storage_ssd.map((component) => (
          <div className='item-catalog'>
          <li key={component.name}>
            <img className='imglist' src={require(`./media/${component.image}.png`)} alt={component.name} />
            <h4 className='component-name'>{component.name}</h4>
            <p>Цена: ${component.price}</p>
            <p>Скорость чтения: {component.readspead}</p>
            <p>Скорость записи: {component.writespead}</p>
            <p>Объем: {component.capacity}</p>
            <button className='button-5' onClick={() => onComponentSelect(component)}>Выбрать</button>
          </li></div>
        ))}
      </ul>
      </div>
      ): itemsselected === 5 ?(
        <div>
        <h3>Каталог жёстких дисков</h3>
        <ul>
          {storage_hdd.map((component) => (
            <div className='item-catalog'>
            <li key={component.name}>
              <img className='imglist' src={require(`./media/${component.image}.png`)} alt={component.name} />
              <h4 className='component-name'>{component.name}</h4>
              <p>Цена: ${component.price}</p>
              <p>Скорость вращения шпинделя: {component.spins}</p>
              <p>Объем: {component.capacity}</p>
              <button className='button-5' onClick={() => onComponentSelect(component)}>Выбрать</button>
            </li></div>
          ))}
        </ul>
        </div>
        ): itemsselected === 6 ?(
          <div>
          <h3>Каталог кулеров</h3>
          <ul>
            {coolersystems.map((component) => (
              <div className='item-catalog'>
              <li key={component.name}>
                <img className='imglist' src={require(`./media/${component.image}.png`)} alt={component.name} />
                <h4 className='component-name'>{component.name}</h4>
                <p>Цена: ${component.price}</p>
                <p>Тип охлаждения: {component.type}</p>
                <p>Предельный уровень шума: {component.noize}</p>
                <p>Максимальное рассеивание телоты(Вт): {component.tdp}</p>
                <p style={{fontSize:'10px'}}>Подходящие сокеты: {component.sockets}</p>
                <button className='button-5' onClick={() => onComponentSelect(component)}>Выбрать</button>
              </li></div>
            ))}
          </ul>
          </div>
          ): itemsselected === 7 ?(
            <div>
            <h3>Каталог блоков питания</h3>
            <ul>
              {psus.map((component) => (
                <div className='item-catalog'>
                <li key={component.name}>
                  <img className='imglist' src={require(`./media/${component.image}.png`)} alt={component.name} />
                  <h4 className='component-name'>{component.name}</h4>
                  <p>Цена: ${component.price}</p>
                  <p>Мощность БП: {component.power}</p>
                  <p>Сертификация: {component.sertification}</p>
                  <p>Формфактор: {component.formfactor}</p>
                  <button className='button-5' onClick={() => onComponentSelect(component)}>Выбрать</button>
                </li></div>
              ))}
            </ul>
            </div>
            ): itemsselected === 8 ?(
              <div>
              <h3>Каталог корпусов</h3>
              <ul>
                {cases.map((component) => (
                  <div className='item-catalog'>
                  <li key={component.name}>
                    <img className='imglist' src={require(`./media/${component.image}.png`)} alt={component.name} />
                    <h4 className='component-name'>{component.name}</h4>
                    <p>Цена: ${component.price}</p>
                    <p>Тип корпуса: {component.type}</p>
                    <p>Формфактор: {component.formfactors}</p>
                    <button className='button-5' onClick={() => onComponentSelect(component)}>Выбрать</button>
                  </li></div>
                ))}
              </ul>
              </div>
              ):(
        <div>
        <p>Вы выбрали все компоненты</p>
        </div>
      )
    }
    </div>
  );
};

export default ComponentCatalog;
