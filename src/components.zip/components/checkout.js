import { useSelector, useDispatch } from 'react-redux';
import React, { useState, useEffect,ReactDOM } from 'react';
import { removeFromCart ,clearTheCart} from './reducers';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import './checkout.css';
const CheckoutPage = () => {
  const cart = useSelector((state) => state.cart.cart);
  const dispatch = useDispatch();
  const [formiscomplete,SetFromIsComplete] = useState(false);
  const HandleCompleteCheckout = (cart) =>{
    dispatch(clearTheCart(cart));
  }
  const Complete = () =>{
    SetFromIsComplete(true);
  }
  return (
    <div className="app-container">
      <div className="row">
        <div className="col no-gutters">
        {formiscomplete === false ? (
          <BuyerForm SetComplete = {Complete}/>
        ):(
          <Checkout/>
        )}
        </div>
      </div>
    </div>
  );
};
const Checkout = (props) => (
 <div className="checkout">
    <div className="checkout-container">
     <h3 className="heading-3">Credit card checkout</h3>
     <Input label="Cardholder's Name" type="text" name="name" />
     <Input label="Card Number" type="number" name="card_number" imgSrc="https://seeklogo.com/images/V/visa-logo-6F4057663D-seeklogo.com.png" />
      <div className="row">
        <div className="col">
          <Input label="Expiration Date" type="month" name="exp_date" />
        </div>
        <div className="col">
          <Input label="CVV" type="number" name="cvv" />
        </div>
      </div>
      <Link to = '/'><Button text="Place order" /></Link>
    </div>
 </div>
);

const Input = (props) => (
  <div className="input">
    <label>{props.label}</label>
    <div className="input-field">
      <input type={props.type} name={props.name} />
      <img src={props.imgSrc}/>
    </div>
  </div>
);

const Button = (props) => (
  <button className="checkout-btn" type="button">{props.text}</button>
);
const BuyerForm = ({SetComplete}) => {
  const [formData, setFormData] = useState({
    fullName: '',
    phoneNumber: '',
    address: '',
    email: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Здесь вы можете добавить логику для обработки отправленной формы
    console.log('Отправленная форма:', formData);
    SetComplete()
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        ФИО:
        <input
          type="text"
          name="fullName"
          value={formData.fullName}
          onChange={handleChange}
          required
        />
      </label>

      <label>
        Номер телефона:
        <input
          type="tel"
          name="phoneNumber"
          value={formData.phoneNumber}
          onChange={handleChange}
          required
        />
      </label>

      <label>
        Адрес:
        <input
          type="text"
          name="address"
          value={formData.address}
          onChange={handleChange}
          required
        />
      </label>

      <label>
        Электронная почта:
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />
      </label>
    <button type="submit" onClick={handleSubmit}>Отправить</button>
    </form>
  );
};



export default CheckoutPage; 