import React, { useRef, useState } from "react";
import * as ReactDOM from "react-dom";
import './manepage.css'
import logo from './media/Pkrama.png'
import {TiChevronLeft, TiChevronRight} from "react-icons/ti"
import { Switch, Route, Link} from 'react-router-dom';
const __ACCELERATION = 1.09;
const __DECELERATION = 0.91;

// This looks awfully "wet" (not DRY) yet... :(

const __processScroll = (scrollDistance) => {  
  let currentHeight = window.scrollY ||  document.body.scrollTop;
  
  if(scrollDistance >= 0) {
    __processScrollDown(scrollDistance, currentHeight, 0, 1);
  } else {
    __processScrollUp(Math.abs(scrollDistance), currentHeight, 0, 1);
  }
}

const __processScrollDown = (distanceLeft, currentHeight, distanceCovered, stepSize) => {
  setTimeout(() => {
    if(distanceLeft > distanceCovered) {
      stepSize = __ACCELERATION*stepSize;
    } else {
      stepSize = Math.ceil(__DECELERATION*stepSize);
    }
    
    window.scrollTo(0, currentHeight);
    
    if(distanceLeft > 0) {
      __processScrollDown(distanceLeft - stepSize, currentHeight + stepSize, distanceCovered + stepSize, stepSize);
    }
  }, 10);
}

const __processScrollUp = (distanceLeft, currentHeight, distanceCovered, stepSize) => {
  setTimeout(() => {
    if(distanceLeft > distanceCovered) {
      stepSize = __ACCELERATION*stepSize;
    } else {
      stepSize = Math.ceil(__DECELERATION*stepSize);
    }
    
    window.scrollTo(0, currentHeight);
    
    if(distanceLeft > 0) {
      __processScrollUp(distanceLeft - stepSize, currentHeight - stepSize, distanceCovered + stepSize, stepSize);
    }
  }, 10);
}

function SmoothScroll(props) {
  const { targetId, children } = props;
  
  const handleScroll = () => {
    if(targetId) {
      const targetElement = document.getElementById(targetId);
      
      if(targetElement) {
        __processScroll(targetElement.getBoundingClientRect().y);
      }
    }
  }
  
  return <div {...props} onClick={handleScroll}>{children}</div>;
}

const ArrowPath = () => (<path d="M11 21.883l-6.235-7.527-.765.644 7.521 9 7.479-9-.764-.645-6.236 7.529v-21.884h-1v21.883z" />);

const MAX_VISIBILITY = 3;
const cardcollection = [
  {title:'Павел Лобарев', content:'Сервис на высшем уровне! Я давно мечтал о мощном игровом компьютере и вот наконец, накопив денег решил заказать его у ПКрамы, не прогадал 10/10!'},
  {title:'Иван Крючков', content:'У меня 2 страсти - Пиво и 3д моделирование, теперь благодаря компьютеру от этой фирмы я могу зарабатывать больше денег на 3д моделировании и покупать больше пива!'},
  {title:'Ольга Кухарева', content:'Купила своему масику Максиму компьютер для учебы, он очень рад, говорит что RX4080 самое то для Visual Studio'},
  {title:'Роман Панда', content:'Купил ПК для видеомонтажа и аудиомонтажа, все надежно, быстро и эффективно. Все летает как вертолеты в варкрафте'},
  {title:'Надеджа Жиляк', content:'Закупали компьютеры для нашей кафедры тут! Самый красивый веб-сайт за всю мою каръеру преподования и лучшый сервис в мире. 12/10'},
  {title:'У програмиста приступ', content:'цоурадшцаугарцргурацдрртоис тмцшгрдуйдрадгйру '},
]

const Carousel = ({children}) => {
  const [active, setActive] = useState(2);
  const count = React.Children.count(children);
  
  return (
    <div className='carousel'>
      {active > 0 && <button className='nav left' onClick={() => setActive(i => i - 1)}><TiChevronLeft/></button>}
      {React.Children.map(children, (child, i) => (
        <div className='card-container' style={{
            '--active': i === active ? 1 : 0,
            '--offset': (active - i) / 3,
            '--direction': Math.sign(active - i),
            '--abs-offset': Math.abs(active - i) / 3,
            'pointer-events': active === i ? 'auto' : 'none',
            'opacity': Math.abs(active - i) >= MAX_VISIBILITY ? '0' : '1',
            'display': Math.abs(active - i) > MAX_VISIBILITY ? 'none' : 'block',
          }}>
          {child}
        </div>
      ))}
      {active < count - 1 && <button className='nav right' onClick={() => setActive(i => i + 1)}><TiChevronRight/></button>}
    </div>
  );
};

function AboutBusiness() {
  return(
    <React.Fragment className='kok'>
      <SmoothScroll id="target-top" targetId="target-middle">
        <button className="scroll">
          <svg className="scroll__frame">
            <rect x="0" y="0" />
          </svg>
          <div className="scroll__content">
            Отзывы
          </div>
          <svg className="scroll__arrow" viewBox="0 0 25 30">
            <ArrowPath />
          </svg>
        </button>
      </SmoothScroll>
      <div className="wildcard">
        <img  src={logo} alt='PKrama' className="pkrama"/>
        <h1>PKrama</h1>
        <p>Лучший магазин компьютерной техники в Минске. Мы предлагаем широкий ассортимент товаров для всех видов деятельности, а так же сами собираем товары по доступной цене и с премиальном качеством</p>
      </div>
      <SmoothScroll id="target-middle" targetId="target-top">
        <button className="scroll">
          <svg className="scroll__frame">
            <rect x="0" y="0" />
          </svg>
          <div className="scroll__content">
            O PKRAMA
          </div>
          <svg className="scroll__arrow up" viewBox="0 0 25 30">
            <ArrowPath />
          </svg>
        </button>
      </SmoothScroll>
      <div className="wildcard-small">
      <div className='app'>
      <Carousel>
        {cardcollection.map((card) => (
          <div className='card'>
          <h2>{card.title}</h2>
          <p>{card.content}</p>
          </div>
        ))}
      </Carousel>
      </div>
        <Link to='/menu'>
        <button className='button-5' >КУПИ СВОЙ КОМПЬЮТЕР ПРЯМО СЕЙЧАС</button>
        </Link>
      </div> 
    </React.Fragment>
  );
}

export default AboutBusiness;
