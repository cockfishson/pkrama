import React from 'react';
import { Link } from 'react-router-dom';
import './Menu.css';
import logo from './media/Pkrama.png'
import gear from './media/custom.png'
import premade from './media/ready.png'
const Menu = () => {
  return (
    <div className='Menuwrap'>
    <div className='header'>
      <img className='logo' src={logo}/>
    </div>
      <div className='MenuButton' id='leftone'>
        <Link to='/ready'>
          <img className='menuimage' src={premade}/>
          <p>Выбрать готовый ПК</p>
        </Link>
      </div>
      <div className='MenuButton' id='rightone'>
        <Link to='/custom'>
          <img className='menuimage' src={gear}/>
          <p>Собрать свой ПК</p>
        </Link>
      </div>
    </div>
  );
}

export default Menu;